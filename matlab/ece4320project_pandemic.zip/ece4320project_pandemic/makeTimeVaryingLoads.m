function [mpcs] = makeTimeVaryingLoads(mpc,T,opts)
% Create loading scenarios for the duration of the simulation.
% Each entry of the structure mpc{i} is a Matpower case corresponding to
% time period i.
% 
% To generate these scenarios, we will use load scaling factors from the
% IEEE RTS test case: https://ieeexplore.ieee.org/document/4113721
% 
% We will use a subset of representative hours from each day, starting a
% specified date and proceeding for a given number of time periods. These
% parameters are specified in the function below.
% 
% The inputs to this function are the system model (mpc) in Matpower format
% at peak load and the standard deviation of a normal perturbation to the
% loads at each time period.
%
% Increase the line failure probabilities slowly over time.


% Parameters for the test cases
Psigma = opts.Psigma;
Pmu = opts.Pmu;
StartWeek = opts.StartWeek;
TimesOfDay = opts.TimesOfDay;
FailureRateIncrease = opts.FailureRateIncrease;

% Data from the IEEE RTS test case: https://ieeexplore.ieee.org/document/4113721
[hourlyLoads,dailyLoads,weeklyLoads] = loadRTSData;

% Define some constants for looking up values in this data
WINTER = 1;
SUMMER = 3;
SPRINGFALL = 5;

% define constants
[PQ, PV, REF, NONE, BUS_I, BUS_TYPE, PD, QD, GS, BS, BUS_AREA, VM, ...
    VA, BASE_KV, ZONE, VMAX, VMIN, LAM_P, LAM_Q, MU_VMAX, MU_VMIN] = idx_bus;

hidx = 0;
didx = 1;
all_didx = 1;
widx = StartWeek;
for i=1:T
    
    mpcs{i} = mpc;
   
    % Calculate hour of day, day of week, and week of year indices
    hidx = hidx + 1;
    if hidx > length(TimesOfDay)
        hidx = 1;
        didx = didx + 1;
        all_didx = all_didx + 1;
    end
    
    if didx > 7
        didx = 1;
        widx = widx + 1;
    end
    
    % Determine load multiplier
    if widx <= 8 || widx >= 44
        season = WINTER;
    elseif (widx >= 9 && widx <= 17) || (widx >= 31 && widx <= 43)
        season = SPRINGFALL;
    elseif widx >= 18 && widx <= 30
        season = SUMMER;
    else
        error('Invalid widx');
    end
    
    if didx <= 5 % Weekday
        hourlyLoadCol = season;
    else % Weekend
        hourlyLoadCol = season + 1;
    end
    
    loadMult = hourlyLoads(TimesOfDay(hidx),hourlyLoadCol) * dailyLoads(didx) * weeklyLoads(widx,2) / 100^3;
    
    % This uses a command from Matlab's statistics toolbox (normrnd).
    % mpcs{i}.bus(:,PD) = mpcs{i}.bus(:,PD)*loadMult .* normrnd(Pmu,Psigma,size(mpc.bus,1),1);
    % To avoid this, we will reformulate this code as follows:
    mpcs{i}.bus(:,PD) = mpcs{i}.bus(:,PD)*loadMult .* (Pmu + Psigma*randn(size(mpc.bus,1),1));
    
    % mpcs{i}.loadMult = loadMult;
    % mpcs{i}.hidx = hidx; mpcs{i}.didx = didx; mpcs{i}.widx = widx;
    
    % Round the load demands to one decimal place
    mpcs{i}.bus(:,PD) = 0.1*round(mpcs{i}.bus(:,PD)*10);

    mpcs{i}.failure_probability = mpcs{i}.failure_probability * FailureRateIncrease^i; % Increase the failure probability for each line due to lack of maintenance.
    
    % Label the date and time
    if hidx == 1
        mpcs{i}.datetime = ['nighttime on day ' int2str(all_didx)];
    elseif hidx == 2
        mpcs{i}.datetime = ['daytime on day ' int2str(all_didx)];
    elseif hidx == 3
        mpcs{i}.datetime = ['evening on day ' int2str(all_didx)];
    else
        error('Invalid hour index');
    end
    
end