% Start the simulation with the GUI
ece4320; 

% Define constants to help reference quantities in the Matpower format.
define_constants; 

% Display the lines with the highest failure probability
sortrows([(1:30).' mpcs{currentTurn}.failure_probability],2,'descend')

% Assign crews to maintain the top two lines in terms of failure probability.
% Two crews assigned to the first, one crew assigned to the second.
crewAllocation(1) = 28; % Assign the first crew to line 28
crewAllocation(2) = 28; % Assign the second crew to line 28
crewAllocation(3) = 25; % Assign the third crew to line 25

% Run a security-constrained unit commitment to determine the generator
% outputs and any load shedding.
contingencies = eye(30,30); % Consider all single-line failure contingencies.
[sol] = rundcscuc(mpcs{currentTurn},contingencies);
printpf(sol); % Show the solution


% Show any load shedding
sortrows([(1:20).' mpcs{currentTurn}.bus(:,PD)-sol.bus(:,PD)],2,'descend')

% Assign the solution from the security-constrained unit commitment to the appropriate variables
Pg = sol.gen(:,PG);
Pd = sol.bus(:,PD);

% Clicking the Take Next Turn button in the GUI results in the following output.
% This output corresponds to what actually happened on the simulation for this turn.
% At the bottom of this output, we see that there is no load shedding, so the total
% cost is just the generation cost. We also see that the line maintenance has reduced
% the failure probabilities at the lines where we allocated our crews earlier.
% More generally, we would also see updates on line failures, line repairs, and crews 
% that are quarantined, when applicable.


[sol] = rundcscuc(mpcs{currentTurn},contingencies);
Pg = sol.gen(:,PG);
Pd = sol.bus(:,PD);