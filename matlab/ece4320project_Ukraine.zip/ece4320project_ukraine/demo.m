% Demo
clear
clc
close all

mpc = ukraine; % Load test case data
nbranch = size(mpc.branch,1); % Number of lines

% Specify defense locations
defense_locations = zeros(nbranch,1);
defense_locations([]) = 1;
defense_locations([]) = 2;
defense_locations([11]) = 3;

% Simulate attack
num_attack = 4;
[expected_load_shed, targeted_lines, outcomes] = simulate_attack(defense_locations,num_attack);

% Indicate the outcome to show on the plot. 2^num_attack will show the 
% outcome where all attacks are successful.
% outcomeIndex = 2^num_attack; 
outcomeIndex = 15;

% Plot this outcome
displayOutcome(defense_locations,outcomes,outcomeIndex)