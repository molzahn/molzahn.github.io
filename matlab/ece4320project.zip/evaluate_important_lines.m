%% Analysis of line contingencies
% Goal: run a bunch of SC-UC problems with each line out of service to see
% when we have to shed load.

clear
clc
close all

% Start the simulation
ece4320;

define_constants;

% Get values for some parameters
nbranch = size(mpcs{1}.branch,1);
nturn = length(mpcs);

% Store the amount of load shedding that we might expect for each turn.
load_shed = zeros(nbranch,nturn);

count = 0;
for i=1:nturn
    for k=1:nbranch % consider all single-line contingencies
        
        % Remove one line from the system at this turn
        mpc = mpcs{i};
        mpc.branch(k,BR_STATUS) = 0;
        
        % Run the DC SC-UC problem, considering all contingencies except
        % for the line we just removed;
        contingencies = eye(nbranch,nbranch);
        contingencies = contingencies(:,[1:k-1 k+1:nbranch]);
        sol = rundcscuc(mpc,contingencies);
        
        load_shed(k,i) = sum(mpc.bus(:,PD)) - sum(sol.bus(:,PD));
        
        
        count = count + 1;
        fprintf('%i of %i\n',count,nturn*nbranch);

    end
end
