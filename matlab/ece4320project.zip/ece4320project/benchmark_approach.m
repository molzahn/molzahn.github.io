function [Pg,Pd,crewAllocation] = benchmark_approach(mpcs,ncrew,currentTurn,lastTurn)
% Solve a security constrained unit commitment at every turn.
% Randomly choose which lines to repair and maintain, weighted by their
% outage statuses and failure probabilities.

%% Set some useful constants
% define constants
[PQ, PV, REF, NONE, BUS_I, BUS_TYPE, PD, QD, GS, BS, BUS_AREA, VM, ...
    VA, BASE_KV, ZONE, VMAX, VMIN, LAM_P, LAM_Q, MU_VMAX, MU_VMIN] = idx_bus;
[F_BUS, T_BUS, BR_R, BR_X, BR_B, RATE_A, RATE_B, RATE_C, ...
    TAP, SHIFT, BR_STATUS, PF, QF, PT, QT, MU_SF, MU_ST, ...
    ANGMIN, ANGMAX, MU_ANGMIN, MU_ANGMAX] = idx_brch;
[GEN_BUS, PG, QG, QMAX, QMIN, VG, MBASE, GEN_STATUS, PMAX, PMIN, ...
    MU_PMAX, MU_PMIN, MU_QMAX, MU_QMIN, PC1, PC2, QC1MIN, QC1MAX, ...
    QC2MIN, QC2MAX, RAMP_AGC, RAMP_10, RAMP_30, RAMP_Q, APF] = idx_gen;
[PW_LINEAR, POLYNOMIAL, MODEL, STARTUP, SHUTDOWN, NCOST, COST] = idx_cost;

nbus = size(mpcs{1}.bus,1);
ngen = size(mpcs{1}.gen,1);
nbranch = size(mpcs{1}.branch,1);

% mpcs{currentTurn}.branch(:,RATE_A) = mpcs{currentTurn}.branch(:,RATE_A) * 1;

%% For reference, load in the parameters that control the simulation
[opts, ~, ~] = setParameters; 

% Controls what fraction of an outaged line is repaired every turn
repairEffectiveness = opts.repairEffectiveness;

%% Formulate the set of contingencies to consider

% Don't consider any contingencies (N-0 security):
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% contingencies = []; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Consider contingencies consisting of the individual failures for each
% line (N-1 security):
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
contingencies = eye(nbranch,nbranch); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Consider contingencies consisting of the individual failures for each
% pair of lines (N-2 security):
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% branch_pairs = nchoosek(1:nbranch,2);
% contingencies = zeros(nbranch,size(branch_pairs,1));
% contingencies(sub2ind(size(contingencies),branch_pairs(:,1),(1:size(branch_pairs,1)).')) = 1;
% contingencies(sub2ind(size(contingencies),branch_pairs(:,2),(1:size(branch_pairs,1)).')) = 1;
% contingencies = [eye(nbranch,nbranch) contingencies]; % Include all N-1 and N-2 contingencies.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Solve a security-constrained unit commitment and prep result for output
[sol] = rundcscuc(mpcs{currentTurn},contingencies);
Pg = sol.gen(:,PG);
Pd = sol.bus(:,PD);

%% Determine the repair crew allocations according to a simple rule
% Simple rule for repair crews: Allocate crews randomly to each outaged
% line, weighted by how close they are to being repaired.
crewAllocation = zeros(ncrew,1);
outaged_lines = find(mpcs{currentTurn}.branch(:,BR_STATUS) ~= 1);

% Randomly order outaged lines, weighted by their outage status such that
% lines which are nearly repaired are assigned crews first.
weighted_status=mpcs{currentTurn}.branch(outaged_lines,BR_STATUS).*rand(length(outaged_lines),1);
[~,order] = sort(weighted_status ,'descend');
ordered_outaged_lines = outaged_lines(order);

% Allocate crews to repair lines. Attempt to have a sufficient number of
% crew allocated to repair a line in one turn.
crewIdx = 1;
for lineIdx = 1:length(ordered_outaged_lines)
   if sum(crewAllocation ~= 0) < ncrew
       % Get the line's status
       lineStatus = mpcs{currentTurn}.branch(ordered_outaged_lines(lineIdx),BR_STATUS);

       % Compute how many crews are needed to repair this line in one turn.
       ncrewRequired = ceil( (1-lineStatus) / repairEffectiveness);

       % How many of the available crews aren't yet allocated?
       ncrewAvailable = ncrew - sum(crewAllocation ~= 0);

       % Allocate up to this number of crews.
       crewsToAllocate = min(ncrewRequired,ncrewAvailable);
       crewAllocation(crewIdx:crewIdx + crewsToAllocate - 1) = ordered_outaged_lines(lineIdx);
       
       % Increment the number of crews allocated
       crewIdx = crewIdx + crewsToAllocate;
   else
       break;
   end
end

%% Allocate the remaining crews to do maintenance according to a simple rule
% Simple rule: Have remaining crews perform maintenance, one crew per line,
% in a randomly selected order that is weighted by failure probabilities.

% Get the indices of the lines in order of decreasing failure probability
failure_probability = mpcs{currentTurn}.failure_probability;
[~,failure_sort] = sort(failure_probability,'descend'); 

for i=1:nbranch
    if sum(crewAllocation ~= 0) < ncrew
        crewAllocation(crewIdx) = failure_sort(i);
        crewIdx = crewIdx + 1;
    else
        break;
    end
end
