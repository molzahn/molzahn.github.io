function [mpc]=dcscuc(mpc,contingencies)
% This function solves a DC security-constrained unit commitment problem
% for the system described in the Matpower case input mpc.
% 
% Load shedding is allowed at the penalized rate specified in mpc.loadcost. 
%
% Contingencies are specified via the contingencies input, which is a 
% matrix with rows corresponding to the lines and columns corresponding to
% the contingencies. Non-zero entries in this matrix indicate which lines
% are outaged. 
%
% Example: Consider a system with 20 lines and three contingencies. The
%          three contingencies are the outage of line 1, the outages of 
%          lines 2 and 4, and the outages of lines 1, 2, and 5.
% 
%          contingencies = zeros(20,3);
%          contingencies(1,1) = 1;          % contingency 1
%          contingencies([2, 4], 2) = 1;    % contingency 2
%          contingencies([1, 2, 5], 3) = 1; % contingency 3
%
% This function outputs a Matpower case variable (mpc) with values
% correpsonding to the base case (non-contingency) quantities.
% 
% This function assumes a well-structured mpc input (network with one
% connected component, bus numbers in increasing consecutive order, 
% out-of-service lines removed). To create an input with this input, you 
% can use rundcscuc, which pre-processes the inputs, calls dcscuc, and 
% post-processes the results.

wrn = warning;
warning off

%% Solver settings
global sdpopts % Define the solver options once for the sake of computational speed
if isempty(sdpopts)
    % Set options for the mixed-integer linear programming solver.
    sdpopts = sdpsettings;

    % This is the built-in solver provided by YALMIP which therefore does not
    % require installation of any other software. This is very slow for large
    % problems but is acceptable for the small problem considered in this
    % project.
    sdpopts.solver = 'intlinprog';

    % Commercial solvers such as Cplex, Gurobi, and Mosek would be much faster,
    % especially for large problems. You can install these (free for students)
    % and enable them here if you want.
    % sdpopts.solver = 'cplex';
    % sdpopts.solver = 'gurobi';
    % sdpopts.solver = 'mosek';

    sdpopts.verbose = 0; % turn off solver output
    sdpopts.cachesolvers = 1; % speed up the code by only searching for available solvers once
end

%% Read in data

% define constants
[PQ, PV, REF, NONE, BUS_I, BUS_TYPE, PD, QD, GS, BS, BUS_AREA, VM, ...
    VA, BASE_KV, ZONE, VMAX, VMIN, LAM_P, LAM_Q, MU_VMAX, MU_VMIN] = idx_bus;
[F_BUS, T_BUS, BR_R, BR_X, BR_B, RATE_A, RATE_B, RATE_C, ...
    TAP, SHIFT, BR_STATUS, PF, QF, PT, QT, MU_SF, MU_ST, ...
    ANGMIN, ANGMAX, MU_ANGMIN, MU_ANGMAX] = idx_brch;
[GEN_BUS, PG, QG, QMAX, QMIN, VG, MBASE, GEN_STATUS, PMAX, PMIN, ...
    MU_PMAX, MU_PMIN, MU_QMAX, MU_QMIN, PC1, PC2, QC1MIN, QC1MAX, ...
    QC2MIN, QC2MAX, RAMP_AGC, RAMP_10, RAMP_30, RAMP_Q, APF] = idx_gen;
[PW_LINEAR, POLYNOMIAL, MODEL, STARTUP, SHUTDOWN, NCOST, COST] = idx_cost;

Sbase = mpc.baseMVA;

Pgmax = mpc.gen(:,PMAX) / Sbase;
Pgmin = mpc.gen(:,PMIN) / Sbase;

ngen = size(mpc.gen,1);
nbus = size(mpc.bus,1);
nbranch = size(mpc.branch,1);

ref = find(mpc.bus(:,BUS_TYPE) == REF);
if isempty(ref)
    if ngen > 0
        ref = mpc.gen(1,GEN_BUS); % Assign the first generator bus as the angle reference unless otherwise defined.
    else
        ref = mpc.bus(1,BUS_I); % Otherwise assign the first bus as the angle reference
    end
end

Pd = mpc.bus(:,PD) / Sbase;

Pflow_max = mpc.branch(:,RATE_A)/Sbase;

% Generation cost (in per unit)
c2 = mpc.gencost(:,COST) * Sbase^2;
c1 = mpc.gencost(:,COST+1) * Sbase;
c0 = mpc.gencost(:,COST+2);

% Load shed cost (in per unit)
load_shed_cost = mpc.loadcost * Sbase;

% Sanity check: In the mpc variable passed to this function, all lines
% should be in service.
if any(mpc.branch(:,BR_STATUS) ~= 1)
    error('All lines for the system passed to dcscuc should be in service.');
end


%% Handle some special cases

% If there are no generators in this system, simply shed all the load.
if ngen == 0
    mpc.bus(:,VA) = 0;
    
    mpc.bus(:,PD) = 0;
    
    mpc.branch(:,PF) = 0;
    mpc.branch(:,PT) = 0;
    
    mpc.f = load_shed_cost * sum(Pd);
    mpc.et = 0;
    mpc.success = 1;
    return;
end

% If there is only a single bus, solve the economic dispatch problem
% (copper plate model) at this bus.
if nbus == 1
    
    Pg = sdpvar(ngen,1); % Power produced by each generator
    status = binvar(ngen,1); % Running / shut down status of each generator    
    Pd_supplied = sdpvar(nbus,1); % Power supplied to each load
    
    constraints = [];
    constraints = [constraints; (Pgmin.*status <= Pg <= Pgmax.*status):'generator limits'];
    constraints = [constraints; (sum(Pg) == sum(Pd_supplied)):'power balance'];
    constraints = [constraints; (0 <= Pd_supplied <= Pd):'load shed limits'];    
    
    cost = c2(c2~=0).'*Pg(c2~=0).^2 + c1.'*Pg + c0.'*status + load_shed_cost * sum(Pd - Pd_supplied);
    
    % Solve the economic dispatch problem
    sdpinfo = solvesdp(constraints,cost,sdpopts);

    if sdpinfo.problem == 0
        % Output solution
        mpc.gen(:,PG) = Pg*Sbase;
        mpc.gen(:,GEN_STATUS) = double(status);

        mpc.bus(:,VA) = 0;
        mpc.bus(:,PD) = double(Pd_supplied)*Sbase;

        mpc.f = double(cost);
        mpc.et = sdpinfo.solvertime;
        mpc.success = 1;
    else
        mpc.gen(:,PG) = 0;
        mpc.bus(:,VA) = 0;

        mpc.f = nan;
        mpc.et = nan;
        mpc.success = 0;
    end
    
    return;
end


%% Set up optimization variables

Pd_supplied = sdpvar(nbus,1); % Power supplied to each load
theta_basecase = sdpvar(nbus,1); % Voltage angles at each bus
theta_basecase(ref) = 0;

Pg = sdpvar(ngen,1); % Power produced by each generator
status = binvar(ngen,1); % Running / shut down status of each generator
Pg_full = sparse(mpc.gen(:,GEN_BUS),ones(ngen,1),Pg,nbus,1);
Pinj = Pg_full - Pd_supplied;


%% Base case constraints and cost (all lines in service)

constraints = [];

constraints = [constraints; (Pgmin.*status <= Pg <= Pgmax.*status):'generator limits'];

% Make susceptance matrix for the base case
[B_basecase, Bf_basecase] = makeBdc(mpc);

% DC power flow formulation
Pflow_basecase = Bf_basecase*theta_basecase;
constraints = [constraints; (B_basecase*theta_basecase == Pinj):'base case power balance'];
constraints = [constraints; (-Pflow_max <= Pflow_basecase <= Pflow_max):'base case flow limits'];
%constraints = [constraints; (theta_basecase(ref) == 0):'base case ref angle'];

% Load shedding formulation
constraints = [constraints; (0 <= Pd_supplied <= Pd):'load shed limits'];

cost = c2(c2~=0).'*Pg(c2~=0).^2 + c1.'*Pg + c0.'*status + load_shed_cost * sum(Pd - Pd_supplied);

%% Contingency constraints

B = []; Bf = []; Pflow_max_c = [];
mpc_basecase = mpc;
ncontingency = size(contingencies,2);
for i=1:ncontingency
    % Formulate DC power flow constraints for this contingency
    mpc_contingency = mpc_basecase;
    mpc_contingency.branch(logical(contingencies(:,i)),:) = [];
    
    [Bi, Bfi] = makeBdc(mpc_contingency);
    B = blkdiag(B,Bi);
    Bf = blkdiag(Bf,Bfi);
    
    Pflow_max_c = [Pflow_max_c; Pflow_max(~contingencies(:,i))];
end
Pinj_c = repmat(Pinj,ncontingency,1);

if ncontingency > 0
    % Stack all the theta variables for all contingencies into one vector
    theta_contingency = sdpvar(nbus*ncontingency,1); % Define new theta variables for each contingency
    theta_contingency(ref:nbus:nbus*ncontingency) = 0;

    Pflow_contingency = Bf*theta_contingency;
    constraints = [constraints; (B*theta_contingency == Pinj_c):'contingency power balance'];
    if ~isempty(Pflow_max_c)
        constraints = [constraints; (-Pflow_max_c <= Pflow_contingency <= Pflow_max_c):'contingency flow limits'];
    end
end

%% Solve and store the solution
c_rescale = 1e4;
sdpinfo = solvesdp(constraints,cost/c_rescale,sdpopts);

if sdpinfo.problem == 0
    % Output solution
    if ngen > 0
        mpc.gen(:,PG) = Pg*Sbase;
        mpc.gen(:,GEN_STATUS) = double(status);
    end
    
    mpc.bus(:,VA) = double(theta_basecase)*180/pi; % Return voltage angles in degrees
    mpc.bus(:,PD) = double(Pd_supplied)*Sbase; % Return voltage angles in degrees
    
    if nbranch > 0
        mpc.branch(:,PF) = double(Pflow_basecase)*Sbase;
        mpc.branch(:,PT) = -double(Pflow_basecase)*Sbase;
    end
    
    mpc.f = double(cost);
    mpc.et = sdpinfo.solvertime;
    mpc.success = 1;
else
    mpc.gen(:,PG) = 0;
    mpc.bus(:,VA) = 0;
    
    mpc.branch(:,PF) = 0;
    mpc.branch(:,PT) = 0;
    
    mpc.f = nan;
    mpc.et = nan;
    mpc.success = 0;
end

warning(wrn);

end