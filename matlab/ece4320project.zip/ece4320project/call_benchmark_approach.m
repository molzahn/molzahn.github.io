display_gui = false;
[mpcs,Pd,mpcs_specified,Pd_specified,crewAllocation,ncrew,score] = power_system_pandemic('benchmark_approach',display_gui);