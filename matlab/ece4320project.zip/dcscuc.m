function [mpc]=dcscuc(mpc,contingencies)
% This function solves a DC security-constrained unit commitment problem
% for the system described in the Matpower case input mpc.
% 
% Load shedding is allowed at the penalized rate specified in mpc.loadcost. 
%
% Contingencies are specified via the contingencies input, which is a 
% matrix with rows corresponding to the lines and columns corresponding to
% the contingencies. Non-zero entries in this matrix indicate which lines
% are outaged. 
%
% Example: Consider a system with 20 lines and three contingencies. The
%          three contingencies are the outage of line 1, the outages of 
%          lines 2 and 4, and the outages of lines 1, 2, and 5.
% 
%          contingencies = zeros(20,3);
%          contingencies(1,1) = 1;          % contingency 1
%          contingencies([2, 4], 2) = 1;    % contingency 2
%          contingencies([1, 2, 5], 3) = 1; % contingency 3
%
% This function outputs a Matpower case variable (mpc) with values
% correpsonding to the base case (non-contingency) quantities.
% 
% This function assumes a well-structured mpc input (network with one
% connected component, bus numbers in increasing consecutive order, 
% out-of-service lines removed). To create an input with this input, you 
% can use rundcscuc, which pre-processes the inputs, calls dcscuc, and 
% post-processes the results.

% Possible concerns:
% - What if the contingency results in islanding the network? Does my
%    current implementation handle this appropriately? I think it does but
%    need to verify.

wrn = warning;
warning off

%% Solver settings
% Set options for the mixed-integer linear programming solver.
sdpopts = sdpsettings;

% This is the built-in solver provided by YALMIP which therefore does not
% require installation of any other software. This is very slow for large
% problems but is acceptable for the small problem considered in this
% project.
sdpopts.solver = 'intlinprog';

% Commercial solvers such as Cplex, Gurobi, and Mosek would be much faster,
% especially for large problems. You can install these (free for students)
% and enable them here if you want.
% sdpopts.solver = 'cplex';
% sdpopts.solver = 'gurobi';
% sdpopts.solver = 'mosek';

sdpopts.verbose = 0; % turn off solver output
sdpopts.cachesolvers = 1; % speed up the code by only searching for available solvers once

%% Read in data
define_constants;

Sbase = mpc.baseMVA;

Pgmax = mpc.gen(:,PMAX) / Sbase;
Pgmin = mpc.gen(:,PMIN) / Sbase;

ngen = size(mpc.gen,1);
nbus = size(mpc.bus,1);
nbranch = size(mpc.branch,1);

ref = find(mpc.bus(:,BUS_TYPE) == REF);
if isempty(ref)
    if ngen > 0
        ref = mpc.gen(1,GEN_BUS); % Assign the first generator bus as the angle reference unless otherwise defined.
    else
        ref = mpc.bus(1,BUS_I); % Otherwise assign the first bus as the angle reference
    end
end

Pd = mpc.bus(:,PD) / Sbase;

Pflow_max = mpc.branch(:,RATE_A)/Sbase;

% Generation cost (in per unit)
c2 = mpc.gencost(:,COST) * Sbase^2;
c1 = mpc.gencost(:,COST+1) * Sbase;
c0 = mpc.gencost(:,COST+2);

% Load shed cost (in per unit)
load_shed_cost = mpc.loadcost * Sbase;

% Sanity check: In the mpc variable passed to this function, all lines
% should be in service.
if any(mpc.branch(:,BR_STATUS) ~= 1)
    error('All lines for the system passed to dcscuc should be in service.');
end


%% Handle some special cases

% If there are no generators in this system, simply shed all the load.
if ngen == 0
    mpc.bus(:,VA) = 0;
    
    mpc.bus(:,PD) = 0;
    
    mpc.branch(:,PF) = 0;
    mpc.branch(:,PT) = 0;
    
    mpc.f = load_shed_cost * sum(Pd);
    mpc.et = 0;
    mpc.success = 1;
    return;
end

% If there is only a single bus, solve the economic dispatch problem
% (copper plate model) at this bus.
if nbus == 1
    
    Pg = sdpvar(ngen,1); % Power produced by each generator
    status = binvar(ngen,1); % Running / shut down status of each generator    
    Pd_supplied = sdpvar(nbus,1); % Power supplied to each load
    
    constraints = [];
    constraints = [constraints; (Pgmin.*status <= Pg <= Pgmax.*status):'generator limits'];
    constraints = [constraints; (sum(Pg) == sum(Pd_supplied)):'power balance'];
    constraints = [constraints; (0 <= Pd_supplied <= Pd):'load shed limits'];    
    
    cost = sum(c2.*Pg.^2 + c1.*Pg) + sum(c0.*status) + load_shed_cost * sum(Pd - Pd_supplied);
    
    % Solve the economic dispatch problem
    sdpinfo = solvesdp(constraints,cost,sdpopts);

    if sdpinfo.problem == 0
        % Output solution
        mpc.gen(:,PG) = Pg*Sbase;
        mpc.gen(:,GEN_STATUS) = double(status);

        mpc.bus(:,VA) = 0;
        mpc.bus(:,PD) = double(Pd_supplied)*Sbase;

        mpc.f = double(cost);
        mpc.et = sdpinfo.solvertime;
        mpc.success = 1;
    else
        mpc.gen(:,PG) = 0;
        mpc.bus(:,VA) = 0;

        mpc.f = nan;
        mpc.et = nan;
        mpc.success = 0;
    end
    
    return;
end


%% Set up optimization variables

Pd_supplied = sdpvar(nbus,1); % Power supplied to each load
theta_basecase = sdpvar(nbus,1); % Voltage angles at each bus
theta_basecase(ref) = 0;

Pg = sdpvar(ngen,1); % Power produced by each generator
status = binvar(ngen,1); % Running / shut down status of each generator
Pg_full = sparse(mpc.gen(:,GEN_BUS),ones(ngen,1),Pg,nbus,1);
Pinj = Pg_full - Pd_supplied;


%% Base case constraints and cost (all lines in service)

constraints = [];

constraints = [constraints; (Pgmin.*status <= Pg <= Pgmax.*status):'generator limits'];

% Make susceptance matrix for the base case
[B_basecase, Bf_basecase] = makeBdc(mpc);

% DC power flow formulation
Pflow_basecase = Bf_basecase*theta_basecase;
constraints = [constraints; (B_basecase*theta_basecase == Pinj):'base case power balance'];
constraints = [constraints; (-Pflow_max <= Pflow_basecase <= Pflow_max):'base case flow limits'];
%constraints = [constraints; (theta_basecase(ref) == 0):'base case ref angle'];

% Load shedding formulation
constraints = [constraints; (0 <= Pd_supplied <= Pd):'load shed limits'];

cost = sum(c2.*Pg.^2 + c1.*Pg) + sum(c0.*status) + load_shed_cost * sum(Pd - Pd_supplied);


%% Contingency constraints

mpc_basecase = mpc;
for i=1:size(contingencies,2)
    % Formulate DC power flow constraints for this contingency
    mpc_contingency = mpc_basecase;
    mpc_contingency.branch(logical(contingencies(:,i)),:) = [];
    
    remainingBranchIdx = find(~contingencies(:,i));
    
    [B{i}, Bf{i}] = makeBdc(mpc_contingency);
    
    theta_contingency{i} = sdpvar(nbus,1); % Define new theta variables for each contingency
    theta_contingency{i}(ref) = 0;
    
    Pflow_contingency{i} = Bf{i}*theta_contingency{i};
    constraints = [constraints; (B{i}*theta_contingency{i} == Pinj):['contingency ' num2str(i) ' power balance']];
    if ~isempty(remainingBranchIdx)
        constraints = [constraints; (-Pflow_max(remainingBranchIdx) <= Pflow_contingency{i} <= Pflow_max(remainingBranchIdx)):['contingency ' num2str(i) ' flow limits']];
    end
    % constraints = [constraints; (theta_contingency{i}(ref) == 0):['contingency ' num2str(i) ' angle reference']];
end

%% Solve and store the solution
c_rescale = 1e4;
sdpinfo = solvesdp(constraints,cost/c_rescale,sdpopts);

if sdpinfo.problem == 0
    % Output solution
    if ngen > 0
        mpc.gen(:,PG) = Pg*Sbase;
        mpc.gen(:,GEN_STATUS) = double(status);
    end
    
    mpc.bus(:,VA) = double(theta_basecase)*180/pi; % Return voltage angles in degrees
    mpc.bus(:,PD) = double(Pd_supplied)*Sbase; % Return voltage angles in degrees
    
    if nbranch > 0
        mpc.branch(:,PF) = double(Pflow_basecase)*Sbase;
        mpc.branch(:,PT) = -double(Pflow_basecase)*Sbase;
    end
    
    mpc.f = double(cost);
    mpc.et = sdpinfo.solvertime;
    mpc.success = 1;
else
    mpc.gen(:,PG) = 0;
    mpc.bus(:,VA) = 0;
    
    mpc.branch(:,PF) = 0;
    mpc.branch(:,PT) = 0;
    
    mpc.f = nan;
    mpc.et = nan;
    mpc.success = 0;
end

warning(wrn);

end