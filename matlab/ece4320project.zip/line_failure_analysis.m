%% Analysis of line contingencies
% Run a bunch of SC-UC problems with each line out of service to see
% which line failures will force us to shed load.

clear
clc

% Start the simulation
ece4320;

define_constants;

% Get parameter values
num_line = size(mpcs{1}.branch,1);
num_turn = length(mpcs);

% Store the amount of load shed in each time period for each line
load_shed = zeros(num_line,num_turn);

% Loop over all lines and all time periods and solve a SC-UC with that line
% out of service (failed) at that time period.
count = 0;
for k=1:num_line
    for i=1:num_turn    
        % Load in the data for this time period
        mpc = mpcs{i};
        mpc.branch(k,BR_STATUS) = 0;
        
        % Run the DC SC UC problem, consider all the N-1 contingencies.
        contingencies = eye(num_line,num_line);
        contingencies = contingencies(:,[1:k-1 k+1:num_line]);
        
        sol = rundcscuc(mpc,contingencies);
        
        load_shed(i,k) = sum(mpc.bus(:,PD)) - sum(sol.bus(:,PD));
        
        count = count + 1;
        fprintf('%i of %i\n',count,num_turn*num_line);
    end
end
