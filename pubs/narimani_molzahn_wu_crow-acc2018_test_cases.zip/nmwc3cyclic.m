function mpc = nmwc3cyclic
% NMWC3CYCLIC
% Data for the cyclic 3-bus system proposed in
%
% M. R. Narimani, D. K. Molzahn, D. Wu, and M. L. Crow, "Empirical 
% Investigation of Non-Convexities in Optimal Power Flow Problems," 
% American Control Conference, Milwaukee, WI, USA, June 2018.
%
% This test case was constructed according to the random procedure 
% described in the reference above. The one-line diagram for this test 
% case along with a projection of this case's feasible space are shown in
% Fig. 4a and Fig. 4b in the reference above. 
%
% Data regarding the best known local solutions are presented at the end of
% this file.
%
% Mohammad Rasoul Narimani, ECE Department, Missouri University of Science 
% and Technology, mn9t5@mst.edu
%
% Daniel K. Molzahn, Energy Systems Division, Argonne National Laboratory, 
% dan.molzahn@gmail.com
%
% Dan Wu, Mechanical Engineering Department, Massachusetts Institute of 
% Technology, danwumit@mit.edu
%
% Mariesa L. Crow, ECE Department, Missouri University of Science 
% and Technology, crow@mst.edu
% 
% March 15, 2018


%% MATPOWER Case Format : Version 2
mpc.version = '2';

%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 100;

%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
mpc.bus = [
1	1	39.01838908	18.94916561	0	0	1	1	0	100	1	1.1	0.9
2	3	39.29632916	21.45576939	0	0	1	1	0	100	1	1.1	0.9
3	2	38.52797026	19.12072484	0	0	1	1	0	100	1	1.1	0.9
   ];
%% generator data
%	bus	Pg	Qg	Qmax	Qmin	Vg	mBase	status	Pmax	Pmin	Pc1	Pc2	Qc1min	Qc1max	Qc2min	Qc2max	ramp_agc	ramp_10	ramp_30	ramp_q	apf

mpc.gen = [
2	5.745409977	7.45847687	100.7229253	-26.11468674	1.029457061	100	1	199.2944874	0	0	0	0	0	0	0	0	0	0	0	0
3	4.524595182	7.362276881	97.84517274	-24.03941638	1.020630194	100	1	199.7901769	0	0	0	0	0	0	0	0	0	0	0	0
];

%% branch data
%	fbus	tbus	r	x	b	rateA	rateB	rateC	ratio	angle	status	angmin	angmax
mpc.branch = [
3	1	0.45553994	0.479557963	0.455453608	381.8422382	397.9769989	401.9064218	1	0	1	-360	360
3	2	0.436935392	0.457330116	0.437689583	398.3541794	395.2622518	402.1285119	1	0	1	-360	360
2	1	0.436220554	0.466325733	0.40680663	397.4592679	399.9372475	401.6236484	1	0	1	-360	360];

%%-----  OPF Data  -----%%
%% area data
%	area	refbus
mpc.areas = [
	1	5;
];

%% generator cost data
%	1	startup	shutdown	n	x1	y1	...	xn	yn
%	2	startup	shutdown	n	c(n-1)	...	c0
mpc.gencost = [
2	0	0	3	0.640835998	49.65172666	0
2	0	0	3	0.697868363	26.78248298	0
	
];


%%%%%%%%%%%%%%%%%%%%%%%%%%% First local solution %%%%%%%%%%%%%%%%%%%%%%%%%%
% The first local solution has an objective value of 10036.96 $/hr.
% This solution is globally optimal since it has the same objective value
% as the best known lower bound.
%
% V_magnitude = [0.9000; 0.9247; 1.0078];
% V_angle = [-7.0637; 0; 2.7115]; % degrees
%
% Pg2 = 40.8002; % MW
% Pg3 = 82.3939; % MW
%
% Qg2 = -26.1147; % MVAr
% Qg3 = -24.0394; % MVAr

%%%%%%%%%%%%%%%%%%%%%%%%%%% Second local solution %%%%%%%%%%%%%%%%%%%%%%%%%
% The second local solution has an objective value of 10426.43 $/hr.
%
% V_magnitude = [0.9000; 0.9868; 0.9434];
% V_angle = [-10.1437; 0; -3.4904]; % degrees
%
% Pg2 = 79.174; % MW
% Pg3 = 43.417; % MW
%
% Qg2 = -26.114; % MVAr
% Qg3 = -24.039; % MVAr

%%%%%%%%%%%%%%%%%%%%%%%%% Objective value bound %%%%%%%%%%%%%%%%%%%%%%%%%%%
% The best known lower bound on the optimal objective value is 10036.96 $/hr.

