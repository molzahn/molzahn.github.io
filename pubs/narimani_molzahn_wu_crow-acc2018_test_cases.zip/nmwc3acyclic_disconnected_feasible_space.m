function mpc = nmwc3acyclic_disconnected_feasible_space
% NMWC3ACYCLIC_DISCONNECTED_FEASIBLE_SPACE
% Data for the acyclic 3-bus system with a disconnected feasible space 
% proposed in
%
% M. R. Narimani, D. K. Molzahn, D. Wu, and M. L. Crow, "Empirical 
% Investigation of Non-Convexities in Optimal Power Flow Problems," 
% American Control Conference, Milwaukee, WI, USA, June 2018.
%
% This test case was constructed according to the random procedure 
% described in the reference above. The one-line diagram for this test 
% case along with a projection of this case's feasible space are shown in
% Fig. 3a and Fig. 3c in the reference above. 
%
% Data regarding the best known local solutions are presented at the end of
% this file.
%
% Mohammad Rasoul Narimani, ECE Department, Missouri University of Science 
% and Technology, mn9t5@mst.edu
%
% Daniel K. Molzahn, Energy Systems Division, Argonne National Laboratory, 
% dan.molzahn@gmail.com
%
% Dan Wu, Mechanical Engineering Department, Massachusetts Institute of 
% Technology, danwumit@mit.edu
%
% Mariesa L. Crow, ECE Department, Missouri University of Science 
% and Technology, crow@mst.edu
% 
% March 15, 2018


%% MATPOWER Case Format : Version 2
mpc.version = '2';

%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 100;

%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
mpc.bus = [
1	1	38.41400291	8.146465141	0	0	1	1	0	100	1	1.21	0.81
2	3	25.79266585	11.36352894	0	0	1	1	0	100	1	1.21	0.81
3	2	25.67252926	9.334802002	0	0	1	1	0	100	1	1.21	0.81
];


%% generator data
% %	bus	Pg	Qg	Qmax	Qmin	Vg	mBase	status	Pmax	Pmin	Pc1	Pc2	Qc1min	Qc1max	Qc2min	Qc2max	ramp_agc	ramp_10	ramp_30	ramp_q	apf


% %10% perturbation vmake the FS disconnected three pieces
% mpc.gen = [
% 2	38.63182654	39.13317002	111.188	-15.721	   0.970312289	100	1	227.471	0	0	0	0	0	0	0	0	0	0	0	0
% 3	40.53810879	40.44364926	107.888	-23.564	   0.997646458	100	1	219.362	0	0	0	0	0	0	0	0	0	0	0	0   
% ]; % correspond to 4180.4


mpc.gen = [
2	0.63182654	15.13317002	111.188	-15.721	   1.09970312	100	1	227.471	  0	0	0	0	0	0	0	0	0	0	0	0
3	90.53810879	20.44364926	107.888	-23.564	   0.81646458	100	1	219.362	  0	0	0	0	0	0	0	0	0	0	0	0  
]; % correspond to 8931.1




%% branch data
%	fbus	tbus	r	x	b	rateA	rateB	rateC	ratio	angle	status	angmin	angmax
mpc.branch = [
2	1	0.356933059	0.454292145	0.461776352	497.4820339	535.2548096	466.4530384	1	0	1	-360	360
1	3	0.434022159	0.42042261	0.477747595	569.0243145	500.1647943	544.2219829	1	0	1	-360	360
];


mpc.gencost =[
2	0	0	3	0.524053206	19.35919442	0
2	0	0	3	0.548069756	16.66154382	0
];

%%%%%%%%%%%%%%%%%%%%%%%%%%% First local solution %%%%%%%%%%%%%%%%%%%%%%%%%
% The first local solution has an objective value of 4180.38 $/hr.
% This solution is globally optimal since it has the same objective value
% as the best known lower bound.
% 
% V_magnitude = [0.8478; 0.8773; 0.8934];
% V_angle = [-10.5425; 0; -0.3972]; % degrees
% 
% Pg2 = 48.4320; % MW
% Pg3 = 47.2891; % MW
%
% Qg2 = -15.7209; % MVAr
% Qg3 = -19.5316; % MVAr

%%%%%%%%%%%%%%%%%%%%%%%%%%% Second local solution %%%%%%%%%%%%%%%%%%%%%%%%%%
% The second local solution has an objective value of 8221.75 $/hr.
% 
% V_magnitude = [0.8100; 0.8100; 1.0338];
% V_angle = [9.3512; 0; 35.5108]; % degrees
%
% Pg2 = 12.2154; % MW
% Pg3 = 105.8708; % MW
%
% Qg2 = 8.8017; % MVAr
% Qg3 = -23.5640; % MVAr

%%%%%%%%%%%%%%%%%%%%%%%%%%% Third local solution %%%%%%%%%%%%%%%%%%%%%%%%%%
% The third local solution has an objective value of 8931.81 $/hr.
%
% V_magnitude = [0.810; 0.987; 0.810];
% V_angle = [-30.612; 0; 4.261]; % degrees
% 
% Pg2 = 111.799; % MW
% Pg3 = 9.819; % MW
%
% Qg2 = -15.7210; % MVAr
% Qg3 = 14.5905; % MVAr

%%%%%%%%%%%%%%%%%%%%%%%%% Objective value bound %%%%%%%%%%%%%%%%%%%%%%%%%%%
% The best known lower bound on the optimal objective value is 4180.38 $/hr.

