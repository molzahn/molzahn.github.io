function mpc = nmwc3acyclic_connected_feasible_space
% NMWC3ACYCLIC_CONNECTED_FEASIBLE_SPACE
% Data for the acyclic 3-bus system with a connected feasible space 
% proposed in
%
% M. R. Narimani, D. K. Molzahn, D. Wu, and M. L. Crow, "Empirical 
% Investigation of Non-Convexities in Optimal Power Flow Problems," 
% American Control Conference, Milwaukee, WI, USA, June 2018.
%
% This test case was constructed according to the random procedure 
% described in the reference above. The one-line diagram for this test 
% case along with a projection of this case's feasible space are shown in
% Fig. 3a and Fig. 3b in the reference above. 
%
% Data regarding the best known local solution are presented at the end of
% this file.
%
% Mohammad Rasoul Narimani, ECE Department, Missouri University of Science 
% and Technology, mn9t5@mst.edu
%
% Daniel K. Molzahn, Energy Systems Division, Argonne National Laboratory, 
% dan.molzahn@gmail.com
%
% Dan Wu, Mechanical Engineering Department, Massachusetts Institute of 
% Technology, danwumit@mit.edu
%
% Mariesa L. Crow, ECE Department, Missouri University of Science 
% and Technology, crow@mst.edu
% 
% February 25, 2018


%% MATPOWER Case Format : Version 2
mpc.version = '2';

%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 100;

%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
mpc.bus = [
1	1	38.41400291	8.146465141	0	0	1	1	0	100	1	1.21	0.81
2	3	25.79266585	11.36352894	0	0	1	1	0	100	1	1.21	0.81
3	2	25.67252926	9.334802002	0	0	1	1	0	100	1	1.21	0.81
];

%% generator data
%	bus	Pg	Qg	Qmax	Qmin	Vg	mBase	status	Pmax	Pmin	Pc1	Pc2	Qc1min	Qc1max	Qc2min	Qc2max	ramp_agc	ramp_10	ramp_30	ramp_q	apf

mpc.gen = [
2	38.63182654	39.13317002	111.188	-28.721	0.970312289	100	1	227.471	0	0	0	0	0	0	0	0	0	0	0	0
3	40.53810879	40.44364926	107.888	-25.564	0.997646458	100	1	219.362	         0	0	0	0	0	0	0	0	0	0	0	0
    
];

%% branch data
%	fbus	tbus	r	x	b	rateA	rateB	rateC	ratio	angle	status	angmin	angmax
mpc.branch = [
2	1	0.356933059	0.454292145	0.461776352	497.4820339	535.2548096	466.4530384	1	0	1	-360	360
1	3	0.434022159	0.42042261	0.477747595	569.0243145	500.1647943	544.2219829	1	0	1	-360	360
];

mpc.gencost =[
2	0	0	3	0.524053206	19.35919442	0
2	0	0	3	0.548069756	16.66154382	0
];

%%%%%%%%%%%%%%%%%%%%%%%%%%%% Local solution %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This local solution has an objective value of 4173.66 $/hr.
% This solution is globally optimal since it has the same objective value
% as the best known lower bound.
%
% V_magnitude = [0.9151; 0.9224; 0.9509];
% V_angle = [-10.2279; 0; -0.9302]; % degrees
%
% Pg2 = 48.3478; % MW
% Pg3 = 47.2770; % MW
%
% Qg2 = -21.5669; % MVAr
% Qg3 = -23.7366; % MVAr

%%%%%%%%%%%%%%%%%%%%%%%%% Objective value bound %%%%%%%%%%%%%%%%%%%%%%%%%%%
% The best known lower bound on the optimal objective value is 4173.66 $/hr.
