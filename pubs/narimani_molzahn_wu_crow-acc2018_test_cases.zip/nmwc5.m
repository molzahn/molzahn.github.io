function mpc = nmwc5 
% NMWC5
% Data for the 5-bus system proposed in
%
% M. R. Narimani, D. K. Molzahn, D. Wu, and M. L. Crow, "Empirical 
% Investigation of Non-Convexities in Optimal Power Flow Problems," 
% American Control Conference, Milwaukee, WI, USA, June 2018.
%
% This test case was constructed according to the random procedure 
% described in the reference above. The one-line diagram for this test 
% case along with a projection of this case's feasible space are shown in
% Fig. 2a and Fig. 2b in the reference above. 
%
% Data regarding the best known local solutions are presented at the end of
% this file.
%
% Mohammad Rasoul Narimani, ECE Department, Missouri University of Science 
% and Technology, mn9t5@mst.edu
%
% Daniel K. Molzahn, Energy Systems Division, Argonne National Laboratory, 
% dan.molzahn@gmail.com
%
% Dan Wu, Mechanical Engineering Department, Massachusetts Institute of 
% Technology, danwumit@mit.edu
%
% Mariesa L. Crow, ECE Department, Missouri University of Science 
% and Technology, crow@mst.edu
% 
% March 15, 2018

 %% MATPOWER Case Format : Version 2
mpc.version = '2';

%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 100;

%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
mpc.bus = [
1	1	89.16190638	14.65556778	0	0	1	1	0	100	1	1.1	0.9
2	1	97.08982329	13.30430683	0	0	1	1	0	100	1	1.1	0.9
3	3	92.20905284	15.01032579	0	0	1	1	0	100	1	1.1	0.9
4	1	105.2300306	14.09672794	0	0	1	1	0	100	1	1.1	0.9
5	2	89.13530979	13.67013861	0	0	1	1	0	100	1	1.1	0.9];
%% generator data
%	bus	Pg	Qg	Qmax	Qmin	Vg	mBase	status	Pmax	Pmin	Pc1	Pc2	Qc1min	Qc1max	Qc2min	Qc2max	ramp_agc	ramp_10	ramp_30	ramp_q	apf
mpc.gen = [
3	160.4004116	92.84811657	1794.105664	-29.84661322	1.023693961	100	1	5005.50424	97.26637057	0	0	0	0	0	0	0	0	0	0	0
5	158.489414	112.1788854	1805.992305	-29.96168679	1.039953453	100	1	2488.874309	104.6653443	0	0	0	0	0	0	0	0	0	0	0 
];
%% branch data
%	fbus	tbus	r	x	b	rateA	rateB	rateC	ratio	angle	status	angmin	angmax
mpc.branch = [
1	5	0.23303896	0.464950713	0.256341869	2502.597245	2492.376248	2500.581173	1	0	1	-360	360
5	4	0.236812785	0.449717556	0.289438369	2490.411039	2494.92247	2488.899887	1.010980424	-1.69345011	1	-360	360
1	3	0.27892815	0.447655483	0.264779222	2494.038331	2482.755161	2505.380781	1	0	1	-360	360
3	2	0.219002557	0.437514084	0.200979822	2511.617882	2522.109708	2493.361495	0.992563321	7.209992372	1	-360	360
4	1	0.290515388	0.430657448	0.284353382	2517.126748	2520.18492	2497.023876	1	0	1	-360	360
2	1	0.255790188	0.467171193	0.171849495	2486.830204	2505.847848	2501.016578	1	0	1	-360	360
5	2	0.256870845	0.463069002	0.215933357	2486.909286	2516.203877	2509.931864	1	0	1	-360	360
4	3	0.251723948	0.448967508	0.272690286	2502.540956	2511.936473	2488.923966	0.995012046	-2.221926923	1	-360	360
2	4	0.23821255	0.450219964	0.251976404	2503.107795	2507.308224	2502.044558	1	0	1	-360	360
3	5	0.230808848	0.421141165	0.203631774	2499.730291	2505.233928	2483.721475	1	0	1	-360	360
];
%%-----  OPF Data  -----%%
%% area data
%	area	refbus
mpc.areas = [
	1	5;
];

%% generator cost data
%	1	startup	shutdown	n	x1	y1	...	xn	yn
%	2	startup	shutdown	n	c(n-1)	...	c0
mpc.gencost = [
2	0	0	3	0.927706807	38.76116051	0
2	0	0	3	0.216193293	54.64994524	0

	
];


%%%%%%%%%%%%%%%%%%%%%%%%%%% First local solution %%%%%%%%%%%%%%%%%%%%%%%%%%
% The first local solution has an objective value of 77238.98 $/hr.
% This solution is globally optimal since it has the same objective value
% as the best known lower bound.
%
% V_magnitude = [0.9605; 0.9514; 1.0063; 0.9503; 1.100];
% V_angle = [-9.6752; -11.4853;0; -10.7676; 10.8399]; % degrees
%
% Pg3 = 128.1529; % MW
% Pg5 = 402.5633; % MW
% 
% Qg3 = -29.8466; % MVAr
% Qg5 = -29.9617; % MVAr

%%%%%%%%%%%%%%%%%%%%%%%%%%% Second local solution %%%%%%%%%%%%%%%%%%%%%%%%%
% The second local solution has an objective value of 114120.27 $/hr.
%
% V_magnitude = [0.9062; 0.9074; 1.0255; 0.9000; 1.0020];
% V_angle = [-18.6309; -20.3543;0; -19.8101; -4.7052]; % degrees
%
% Pg3 = 291.798; % MW
% Pg5 = 228.786; % MW
%
% Qg3 = -29.8466; % MVAr
% Qg5 = -29.9617; % MVAr

%%%%%%%%%%%%%%%%%%%%%%%%% Objective value bound %%%%%%%%%%%%%%%%%%%%%%%%%%%
% The best known lower bound on the optimal objective value is 77238.98 $/hr.

