function mpc = nmwc4
% NMWC4
% Data for the 4-bus system proposed in
%
% M. R. Narimani, D. K. Molzahn, D. Wu, and M. L. Crow, "Empirical 
% Investigation of Non-Convexities in Optimal Power Flow Problems," 
% American Control Conference, Milwaukee, WI, USA, June 2018.
%
% This test case was constructed according to the random procedure 
% described in the reference above. The one-line diagram for this test 
% case along with a projection of this case's feasible space are shown in
% Fig. 1a and Fig. 1b in the reference above. 
%
% Data regarding the best known local solutions are presented at the end of
% this file.
%
% Mohammad Rasoul Narimani, ECE Department, Missouri University of Science 
% and Technology, mn9t5@mst.edu
%
% Daniel K. Molzahn, Energy Systems Division, Argonne National Laboratory, 
% dan.molzahn@gmail.com
%
% Dan Wu, Mechanical Engineering Department, Massachusetts Institute of 
% Technology, danwumit@mit.edu
%
% Mariesa L. Crow, ECE Department, Missouri University of Science 
% and Technology, crow@mst.edu
% 
% March 15, 2018


%% MATPOWER Case Format : Version 2
mpc.version = '2';

%%-----  Power Flow Data  -----%%
%% system MVA base
mpc.baseMVA = 100;

%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
mpc.bus = [
1	1	24.08979171	16.10617684	0	0	1	1	0	100	1	1.1	0.9
2	1	22.72928007	19.50049985	0	0	1	1	0	100	1	1.1	0.9
3	3	25.6285211	12.90765973	0	0	1	1	0	100	1	1.1	0.9
4	2	25.06140558	17.48799173	0	0	1	1	0	100	1	1.1	0.9

];

%% generator data
%	bus	Pg	Qg	Qmax	Qmin	Vg	mBase	status	Pmax	Pmin	Pc1	Pc2	Qc1min	Qc1max	Qc2min	Qc2max	ramp_agc	ramp_10	ramp_30	ramp_q	apf
mpc.gen = [
3	50.43112887	2.026966961	58.97725809	-55.3617257	1.009581102	100	1	57.3050351	24.43796984	0	0	0	0	0	0	0	0	0	0	0
4	49.04374811	0.482338325	55.15214462	-53.4740214	0.99636911	100	1	54.3250762	22.62966505	0	0	0	0	0	0	0	0	0	0	0
];

%% branch data
%	fbus	tbus	r	x	b	rateA	rateB	rateC	ratio	angle	status	angmin	angmax
mpc.branch = [
1	3	0.388554626	0.39056829	0.40165547	998.8829365	989.6166365	981.0809368	1	0	1	-360	360
3	4	0.375148097	0.361582171	0.387021028	994.1032313	975.6445709	982.301098	1	0	1	-360	360
4	2	0.35746676	0.427760881	0.410721933	1002.566849	1007.393936	1002.537758	1	0	1	-360	360
1	2	0.379021768	0.380918389	0.380424689	1012.652702	994.8750697	1000.691398	1	0	1	-360	360

];

%%-----  OPF Data  -----%%
%% generator cost data
%	1	startup	shutdown	n	x1	y1	...	xn	yn
%	2	startup	shutdown	n	c(n-1)	...	c0
mpc.gencost = [
2	0	0	3	0.066348429	67.22676458	0
2	0	0	3	0.627252965	15.05433235	0

];


%%%%%%%%%%%%%%%%%%%%%%%%%%%% First local solution %%%%%%%%%%%%%%%%%%%%%%%%%
% This local solution has an objective value of 6174.02 $/hr.
% This solution is globally optimal since it has the same objective value
% as the best known lower bound.
%
% V_magnitude = [0.9013; 0.9000; 0.9539; 0.9428];
% V_angle = [-10.2513; -10.1181; 0; -0.3540]; % degrees
%
% Pg2 = 55.694; % MW
% Pg3 = 48.743; % MW
%
% Qg2 = -33.399; % MVAr
% Qg3 = -27.894; % MVAr

%%%%%%%%%%%%%%%%%%%%%%%%% Objective value bound %%%%%%%%%%%%%%%%%%%%%%%%%%%
% The best known lower bound on the optimal objective value is 6174.02 $/hr.

